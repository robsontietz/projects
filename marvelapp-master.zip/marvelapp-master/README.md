# marvelheroes

Conheça todos os Heróis da Marvel

Aplicativo para navergar e conhecer todos os heróis da Marvel pela própria base de dados da Marvel, feito para fins de estudo, para o aplicativo funcionar é preciso colocar no arquivo de repositories heroesservices os dados de sua key para consulta a API da Marvel.
